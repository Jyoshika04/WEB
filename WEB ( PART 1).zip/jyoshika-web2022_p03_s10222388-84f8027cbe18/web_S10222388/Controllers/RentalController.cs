﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

using Microsoft.AspNetCore.Http;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using web_S10222388.Models;

namespace web_S10222388.Controllers
{
    public class RentalController : Controller
    {
        private List<int> numLoanDays = new List<int> { 2, 5, 10, 20 };
        private List<double> rentalRates = new List<double> { 1.0, 1.50, 2.50, 5.00 };

        private List<SelectListItem> numBooks = new List<SelectListItem>();
        private List<RentalDiscount> discountList = new List<RentalDiscount>();

        public RentalController()
        {
            for (int i = 1; i <= 10; i++)
            {
                numBooks.Add(
                new SelectListItem
                {
                    Value = i.ToString(),
                    Text = i.ToString(),
                });
            }
            discountList.Add(
                new RentalDiscount
                {
                    Description = "Student Membership (20%)",
                    DiscountPercent = 20,
                    Selected = false
                });
            discountList.Add(
                new RentalDiscount
                {
                    Description = "Birthday Discount (10%)",
                    DiscountPercent = 10,
                    Selected = false
                });

        }

        public ActionResult Calculate()
        {
            // Stop accessing the action if not logged in
            // or account not in the "Staff" role
            if ((HttpContext.Session.GetString("Role") == null) ||
            (HttpContext.Session.GetString("Role") != "Staff"))
            {
                return RedirectToAction("Index", "Home");
            }

            ViewData["ShowResult"] = false;
            ViewData["NumBooks"] = numBooks;
            ViewData["NumDays"] = numLoanDays;

            Rental rental = new Rental
            {
                LoanDate = DateTime.Today,
                NumBooks = Convert.ToInt32(numBooks[0].Value),
                NumDays = numLoanDays[0],
                Discounts = discountList
            };
            return View(rental);
        }

        [HttpPost]
        public ActionResult Calculate(Rental rental)
        {
            ViewData["ShowResult"] = true;
            ViewData["NumBooks"] = numBooks;
            ViewData["NumDays"] = numLoanDays;

            rental.DueDate = rental.LoanDate.AddDays(rental.NumDays);
            int selectedIndex = numLoanDays.IndexOf(rental.NumDays);
            rental.RentalRate = rentalRates[selectedIndex];
            rental.RentalFee = rental.NumBooks * rental.NumDays * rental.RentalRate;
            rental.DiscountPercent = 0.0;
            foreach (RentalDiscount discountItem in rental.Discounts)
            {
                if (discountItem.Selected)
                    rental.DiscountPercent += discountItem.DiscountPercent;
            }

            // Calculate the amount payable
            rental.AmountPayable = rental.RentalFee *
            (100 - rental.DiscountPercent) / 100;
            // Route to Calculate.cshtml view to display result
            // contained in the rental object
            return View(rental);


        }

        
    }
}
