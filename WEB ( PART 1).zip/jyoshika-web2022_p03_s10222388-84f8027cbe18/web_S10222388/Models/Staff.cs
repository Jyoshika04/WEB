﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace web_S10222388.Models
{
    public class Staff
    {
     
        // for SatffId property
        [Display(Name = "ID")]
        public int StaffId { get; set; }
        // for Name property
        [Required(ErrorMessage = "Please enter a name!")]
        [StringLength(50, ErrorMessage ="Name cannot exceed 50 characters")]
        public string Name { get; set; }
        // for gender property
        public char Gender { get; set; }
        // for DOB property
        [Display(Name = "Date of Birth")]
        [DataType(DataType.Date)]
        public DateTime? DOB { get; set; }
        // for nationality property
        public string Nationality { get; set; }
        // for Email property
        [Display(Name = "Email Address")]
        [EmailAddress]
        //[RegularExpression(@"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+/.[A-Za-z]{2,4}")]
        // Custom Validation Attribute for checking email address exists
        [ValidateEmailExists]
        public string Email { get; set; }
        // for salary property
        [Display(Name = "Monthly Salary (SGD)")]
        [DisplayFormat(DataFormatString = "{0:#,##0.00}")]
        [Range(1.00,10000.00, ErrorMessage = "Salary must be between 1.00 to 10,000.00")]
        
        public decimal Salary { get; set; }
        // for IsFullTime property
        [Display(Name = "Full-Time Staff")]
        public bool IsFullTime { get; set; }

        // for BranchNo property
        [Display(Name = "Branch")]
        public int? BranchNo { get; set; }






    }
}
