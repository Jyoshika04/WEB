﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace web_S10222388.Models
{
    public class Rental
    {
        [Display(Name = "Loan Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}")]
        public DateTime LoanDate { get; set; }
        [Display(Name = "Number of Books")]

        // HELP!!//
        public int NumDays { get; set; }
        [Display(Name = "Number of Days")]
        [DisplayFormat(DataFormatString = "{0:#,##0.00}")]


        public int NumBooks { get; set; }
        [Display(Name = "Rental Rate (SGD)")]
        [DisplayFormat(DataFormatString = "{0:#,##0.00}")]
        public double RentalRate { get; set; }
        [Display(Name = "Due Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}")]
        public DateTime DueDate { get; set; }
        [Display(Name = "Rental Fee (SGD)")]
        [DisplayFormat(DataFormatString = "{0:#,##0.00}")]
        
        
        public double RentalFee { get; set; }
        [Display(Name = "Discount Given (%)")]
        [DisplayFormat(DataFormatString = "{0:#0.0}")]


        //HELP !!!
        public double AmountPayable { get; set; }
        [Display(Name = "Amount Payable (SGD)")]
        [DisplayFormat(DataFormatString = "{0:#,##0.00}")]
        // HELP 


        public double DiscountPercent { get; set; }
        [Display(Name = "Discount Given (%)")]
        public List<RentalDiscount> Discounts { get; set; }

        
        

    }


public class RentalDiscount
    {
        public string Description { get; set; }
        public double DiscountPercent { get; set; }
        public bool Selected { get; set; }
    }

}
