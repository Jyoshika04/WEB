﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace web_S10222388.Models
{
    public class Branch
    {
        //adding BrachNo
        [Display(Name = "ID")]
        public int BranchNo { get; set; }

        public string Address { get; set; }

        [RegularExpression(@"[689]\d{7}|\+65[689]\d{7}$", 
            ErrorMessage = "Invalid Singapore Phone Number")]
        public string Telephone { get; set; }

    }
}
