﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebAssignment.Models;
using Microsoft.AspNetCore.Http;

namespace WebAssignment.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

       

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult StaffLogin(IFormCollection formData) // collect input fro index and store 
        {
            // Read inputs from textboxes
            // Email address converted to lowercase
            string loginID = formData["txtLoginID"].ToString(); // conversation
            string password = formData["txtPassword"].ToString();
            // formData["txtPassword"] is bascially from thr front end, the ID  id="txtLoginID".
            // TO DO ???
            //string Staff = formData["txtRole"].ToString();
            if (loginID == "ProductManager" && password == "passProduct") // checking 
            {
                // Store Login ID in session with the key “LoginID”
                HttpContext.Session.SetString("LoginID", loginID);
                // Store user role “Staff” as a string in session with the key “Role”
                // TO DO\
                HttpContext.Session.SetString("Role", "ProductManager");

                //
                HttpContext.Session.SetString("LoggedInTime", DateTime.Now.ToString(" dd MMM yyy HH':'mm':'ss "));



                // Redirect user to the "StaffMain" view through an action
                return RedirectToAction("ProductMain");
            }
            else
            {
                // Store an error message in TempData for display at the index view
                TempData["Message"] = "Invalid Login Credentials!";

                // Redirect user back to the index view through an action
                return RedirectToAction("Index");
            }
        }
        public ActionResult ProductMain()
        {
            // Stop accessing the action if not logged in
            // or account not in the "Staff" role
            if ((HttpContext.Session.GetString("Role") == null) ||
            (HttpContext.Session.GetString("Role") != "ProductManager"))
            {
                return RedirectToAction("Index", "Home");
            }

            return View();
        }
        public ActionResult LogOut()
        {
            string loginTime = HttpContext.Session.GetString("LoggedInTime");
            TimeSpan totaltime = DateTime.Now - Convert.ToDateTime(loginTime);
            string sessionlenght = totaltime.Seconds.ToString();

            // Clear all key-values pairs stored in session state
            HttpContext.Session.Clear();
            TempData["LogOutMessage"] = ("You have logged in for " + sessionlenght + " seconds");

            // Call the Index action of Home controller
            return RedirectToAction("Index");
        }



        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
